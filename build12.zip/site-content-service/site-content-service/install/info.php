<?php if(!defined("PROCESSWIRE_INSTALL")) die();
$info = array(
	'title' => "Content Service", 
	'summary' => "Лучшая сборка на данный момент. Все свои пожелания можете высказать Алексею. Он их учтет и что-нибудь сделает. В сборку входят: AdminOnSteroids, ProcessDatabaseBackups, AllInOneMinify, TracyDebugger, Repeater. Так же растет красивое дерево и ничего не нужно писать в конфиг. 

changelog:
1)Исправлена политика!", 
	'screenshot' => ""
	);
