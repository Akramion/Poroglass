CKEDITOR.plugins.setLang('linkfilesmenu', 'en', {
	lfm_button_label: 'Insert link to file'
});
