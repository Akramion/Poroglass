CKEDITOR.plugins.setLang( 'token', 'en', {
	title: 'Token Insertion',
	toolbar: 'Token',
	name: 'Token to Insert',
	pathName: 'token'
} );
