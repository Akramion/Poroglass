AdminOnSteroids
========================

Various ProcessWire admin tweaks to boost productivity.

[Documentation](https://github.com/rolandtoth/AdminOnSteroids/wiki/Home) • [Forum](https://processwire.com/talk/topic/13389-adminonsteroids/) • [Modules Directory](http://modules.processwire.com/modules/admin-on-steroids/) • [Donate](https://www.paypal.me/rolandtothpal/5)


![AdminOnSteroids 1.6.4](https://rolandtoth.hu/pic/aos/aos164.png "AdminOnSteroids 1.6.4")
