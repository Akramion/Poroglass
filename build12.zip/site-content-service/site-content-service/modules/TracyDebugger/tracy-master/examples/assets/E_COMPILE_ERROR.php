<?php

$this = 2;
