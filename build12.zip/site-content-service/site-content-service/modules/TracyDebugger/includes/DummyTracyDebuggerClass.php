<?php namespace Tracy;

use Tracy;

class Debugger {

	public static function barDump() {
		return false;
	}

	public static function dump() {
		return false;
	}

	public static function log() {
		return false;
	}

	public static function timer() {
		return false;
	}

	public static function fireLog() {
		return false;
	}

}